﻿namespace AUTO1_3196324
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private async void OnSumarClicked(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(entry1.Text) || string.IsNullOrEmpty(entry2.Text))
            {
                await DisplayAlert("Error", "Introduce todos los numeros", "OK");
            }
            else
            {
                double num1 = Convert.ToDouble(entry1.Text);
                double num2 = Convert.ToDouble(entry2.Text);
                double suma = num1 + num2;

                entryResultado.Text = suma.ToString();
            }
        }
    }
}