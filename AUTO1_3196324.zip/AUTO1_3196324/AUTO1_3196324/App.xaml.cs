﻿using Microsoft.Extensions.DependencyInjection;

namespace AUTO1_3196324
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            MainPage = new MainPage();
        }
    }
}